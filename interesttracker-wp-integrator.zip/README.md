# interesttracker-wp-integrator
WordPress plugin for integrating Gravity Forms responses with InterestTracker

THIS PLUGIN WAS NEVER DEVELOPED. We chose to use Gravity Forms REST API V2 instead for pulling form entries into InterestTracker. (LW 6/14/2022)

## How to make release

Step1: Make changes in main branch - either by merge with other branch or making changes in main branch.
Step 2: Increment version in main file(For eg: if there is Version: 0.1 then change to Version: 0.2). The main file is basically in root location with same name of plugin(main file name: interesttracker-wp-integrator.php).
Step 3: Commit and push to main branch
Step 4: Go to git hub repo. Click "tags". It is just beside "Go to file" search box.
Step 5: Click "Draft a new release".
Step 6: Enter data in "Choose a tag" , "Release Title", "Describe the title" .
Step 7: Go to your wordpress plugin list.click button "check for updates" to get new update .


Developer: Rabi Gorkhali
Email: rabigorkhaly@gmail.com