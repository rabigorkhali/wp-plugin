# interesttracker-wp-integrator
WordPress plugin for integrating Gravity Forms responses with InterestTracker

THIS PLUGIN WAS NEVER DEVELOPED. We chose to use Gravity Forms REST API V2 instead for pulling form entries into InterestTracker. (LW 6/14/2022)
