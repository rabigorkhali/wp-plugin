# interesttracker-wp-integrator
WordPress plugin for integrating Gravity Forms responses with InterestTracker

## How to make release

<p>Step1: Make changes in main branch - either by merge with other branch or making changes in main branch.</p>
Step 2: Increment version in main file(For eg: if there is Version: 0.1 then change to Version: 0.2). The main file is basically in root location with same name of plugin(main file name: interesttracker-wp-integrator.php).</p>
Step 3: Commit and push to main branch.</p>
Step 4: Go to git hub repo. Click "tags". It is just beside "Go to file" search box.</p>
Step 5: Click "Draft a new release".</p>
Step 6: Enter data in "Choose a tag" , "Release Title", "Describe the title" .</p>
Step 7: Go to your wordpress plugin list.click button "check for updates" to get new update .</p>


Developer: Rabi Gorkhali
Email: rabigorkhaly@gmail.com